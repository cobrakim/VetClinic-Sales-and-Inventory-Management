
**Admin Login Details**
Username: admin
Password: admin123


**Doctor Login Details**
Username: jett1234
Password: jett1234


**Patient Login Details**
Username: chloe1234
Password: chloe1234


**Making an appointment creates account for the patient**

