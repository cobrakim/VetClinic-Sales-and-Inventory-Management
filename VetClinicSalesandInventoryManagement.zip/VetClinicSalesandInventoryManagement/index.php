<style>
.main-banner {
  background-color: lightblue;
}
</style>
<body>	
  <?php include 'header.php';?>
  <!-- Bnr Header -->
  <section class="main-banner">
    <div class="tp-banner-container">
      <div class="tp-banner">
         <center> <h1><strong>Vet-Clinic Sales and Inventory Management</h1>
            <img src="images/hms2.jpg"  alt="slider"  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat"> 

  </section>

    

  


  
  <!-- Footer -->
<?php include 'footer.php';?>